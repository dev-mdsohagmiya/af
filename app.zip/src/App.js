import "./App.css";
import "./styles/bootstrap/custom-bootstrap.css";

import Layout from "./Layout";

function App() {
  return (
    <>
      <div>
        <Layout />
      </div>
    </>
  );
}

export default App;
